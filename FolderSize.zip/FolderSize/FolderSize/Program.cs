﻿using System;
using System.IO;

namespace folderSize
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(@"Please enter a space separeted double Values : ");
            var paramList = Console.ReadLine().Split(' '); 
            var param1 = Convert.ToString(paramList[0]);
            var param2 = Convert.ToString(paramList[1]);
            if (!Directory.Exists(param1))
            {
                Console.WriteLine("not Exist this directory... please try again.");
            }

            else
            {
                DirectoryInfo ForOperation = new DirectoryInfo(param1);
                switch (param2)
                {
                    case "1":
                        Console.WriteLine("The size is {0} MegaBytes.", DirSize(ForOperation).ToSize(MyExtension.SizeUnits.MB));
                        Console.WriteLine("The size is {0} KiloBytes.", DirSize(ForOperation).ToSize(MyExtension.SizeUnits.KB));
                        Console.WriteLine("The size is {0} Bytes.", DirSize(ForOperation));
                        break;
                    case "2":
                        Check(param1, 1);
                        break;
                    default:
                        Console.WriteLine($"An unexpected value... please try again.");
                        break;
                }

            }
            //Console.WriteLine("Enter Folder Url:");
            //string url  =  Console.ReadLine();

            //if (!Directory.Exists(url))
            //{
            //    Console.WriteLine("not Exist this directory... please try again.");
            //}
            //else
            //{
            //Console.WriteLine("Enter Operation: (1)-Folder Volume or (2)-Folder Volume Details ");
            //string s = Console.ReadLine();
            //    DirectoryInfo ForOperation=new DirectoryInfo(@url);
            //    switch (s)
            //    {
            //        case "1":
            //            Console.WriteLine("The size is {0} MegaBytes.", DirSize(ForOperation).ToSize(MyExtension.SizeUnits.MB));
            //            Console.WriteLine("The size is {0} KiloBytes.", DirSize(ForOperation).ToSize(MyExtension.SizeUnits.KB));
            //            Console.WriteLine("The size is {0} Bytes.", DirSize(ForOperation));
            //            break;
            //        case "2":
            //            Check(url, 1);
            //            break;
            //        default:
            //             Console.WriteLine($"An unexpected value... please try again.");
            //            break;
            //    }

            //}











        }

        public static long DirSize(DirectoryInfo d)
        {
            long size = 0;
            FileInfo[] fis = d.GetFiles();
            foreach (FileInfo fi in fis)
            {
                size += fi.Length;
            }
           
            DirectoryInfo[] dis = d.GetDirectories();
            foreach (DirectoryInfo di in dis)
            {
                size += DirSize(di);
            }
            return size;
        }

        public static long DirSizeWithOutSub(DirectoryInfo d)
        {
            long size = 0;
            FileInfo[] fis = d.GetFiles();
            foreach (FileInfo fi in fis)
            {
                size += fi.Length;
            }
            return size;
        }

        static void Check(string link, int c)
        {
            System.IO.DirectoryInfo dirInfo = new System.IO.DirectoryInfo(@link);

            long size = 0;
            if (c == 1)
            {
                Console.WriteLine("{0}(MainFolderName)(FolderSize:{1}KB)", dirInfo.Name, DirSize(dirInfo).ToSize(MyExtension.SizeUnits.KB));
            }
            FileInfo[] f1 = dirInfo.GetFiles();
            DirectoryInfo[] dis1 = dirInfo.GetDirectories();

            foreach (FileInfo f1s in f1)
            {
                size = f1s.Length;
                Console.WriteLine("{2} {0}(FileName)(Size:{1}KB)", f1s.Name, size.ToSize(MyExtension.SizeUnits.KB), dash(c));
            }
            foreach (DirectoryInfo dis1s in dis1)
            {

                if (DirSizeWithOutSub(dis1s) == 0)
                {
                    Console.WriteLine("{2} {0}(FolderName)(FolderSize:{1}KB)", dis1s.Name, DirSize(dis1s).ToSize(MyExtension.SizeUnits.KB), dash(c));
                }
                else
                {
                    Console.WriteLine("{2} {0}(FolderName)(FolderSize:{1}KB)", dis1s.Name, DirSizeWithOutSub(dis1s).ToSize(MyExtension.SizeUnits.KB), dash(c));

                }
                
                string l = @"" + dis1s.FullName + "";

                Check(l, c + 5);

            }

        }

        static string dash(int number)
        {
            string dash = "-";

            for (int i = 0; i < number; i++)
            {
                dash += "-";
            }

            return dash;
        }


    }
}