﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TextComparator.Controllers.ForLists;

namespace TextComparator.ViewModel
{
    public class Mistake
    {
        public List<TextWord> MistaceOrigin { get; set; }
        public List<TextWord> MistaceChange { get; set; }
        public bool Empty
        {
            get
            {
                return (MistaceOrigin == null);
            }
        }
    }

}
