﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TextComparator.Controllers.ForLists
{
    public class TextWord
    {
        public int RowIdFR { get; set; }
        public string Text { get; set; }
      
        public int WordId { get; set; }
        public string RowText { get; set; }

        
    }
}
